---------------------------------------
-- 公用组件支持数据
-- 与核心系统对照二级代码 
---------------------------------------
insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC161', 'ID_COUNTRY', '国家/地区代码');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAA027', 'AGENCY_CODE', '统筹区');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('BAB009', 'FUNDS_SOURCE', '经费来源');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAB022', 'BUSINESS_CODE', '行业代码');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAB021', 'SUB_RELATION', '隶属关系');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC011', 'EDUCATION_LEVEL', '学历');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAB019', 'UNIT_TYPE', '单位类型');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC009', 'HOUSEHOLD_TYPE', '户口性质');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('BAC062', 'PROFILE_STATUS', '人员登记状态');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC058', 'ID_TYPE', '证件类型');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC004', 'SEX', '性别');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC005', 'NATION', '民族');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAB006', 'BUZZLNS_TYPE', '工商营业执照种类');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAB051', 'COMPANY_PAYMENT_STATE', '单位参保状态');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC066', 'INSURANT_TYPE', '参保身份');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('BIC268', 'CONTACT_RELATION', '亲属关系');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC050', 'CHANGE_TYPE', '变更类型');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC012', 'PERSONAL_STATUS', '个人身份');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC031', 'PAYMENT_STATE', '人员缴费状态');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAE140', 'INSURANCE_CODE', '险种类型');
 
insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC084', 'RETIRE_STATUS', '离退休状态');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAE160', 'CHANGE_REASON', '变更原因');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAA115', 'PAYMENT_TYPE', '缴费类型');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC020', 'ADMINISTRATIVE_POST', '行政职务');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAC013', 'EMPLOYMENT_FORM', '用工形式');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAB020', 'ECONOMICS_TYPE', '经济类型');

insert into CODE_CONTRAST (SIMIS_CODE, SIPUB_CODE, DISCRIPT)
values ('AAB034', 'AGENCY_NUMBER', '经办机构编码');
