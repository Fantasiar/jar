---------------------------------------
-- 公用组件支持数据
-- 公共服务二级代码 
---------------------------------------

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121701', 'APPLY_TYPE', '1101', '申报类型', '单位信息修改');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121703', 'APPLY_TYPE', '1102', '申报类型', '单位有变动核定申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121704', 'APPLY_TYPE', '1103', '申报类型', '单位无变动核定申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121705', 'APPLY_TYPE', '1201', '申报类型', '职工信息修改');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121707', 'APPLY_TYPE', '1202', '申报类型', '职工新增申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121708', 'APPLY_TYPE', '1203', '申报类型', '职工减少申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121709', 'APPLY_TYPE', '1204', '申报类型', '职工退休申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121710', 'APPLY_TYPE', '1205', '申报类型', '职工缴费工资申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121711', 'APPLY_TYPE', '1206', '申报类型', '职工补缴申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121712', 'APPLY_TYPE', '1207', '申报类型', '职工补差申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121713', 'APPLY_TYPE', '1211', '申报类型', '离退休人员信息修改');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121715', 'APPLY_TYPE', '1212', '申报类型', '养老待遇暂停申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121716', 'APPLY_TYPE', '1241', '申报类型', '工伤待遇申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121717', 'APPLY_TYPE', '1242', '申报类型', '工伤定点申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121718', 'APPLY_TYPE', '1251', '申报类型', '生育津贴申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121719', 'APPLY_TYPE', '1252', '申报类型', '生育定点申报');

insert into code_list_sipub (ID, TYPE, VALUE, DISCRIPT, NAME)
values ('201608121720', 'APPLY_TYPE', '1253', '申报类型', '生育定点变更');
