--申报编号 流水号  
create sequence SEQ_APPLYNUMBER
minvalue 1000001
maxvalue 9999999
start with 1000001
increment by 1
cache 10000
cycle;

-- Create table
--增员申报表 
-- Create table
create table APPLY_EMP_REGISTER
(
  ID                       VARCHAR2(32) not null,
  ID_TYPE                  VARCHAR2(3),
  ID_NUMBER                VARCHAR2(22),
  ID_COUNTRY               VARCHAR2(3),
  NAME                     VARCHAR2(50),
  SEX                      VARCHAR2(3),
  NATION                   VARCHAR2(3),
  BIRTHDAY                 NUMBER(8),
  WORK_DATE                NUMBER(8),
  ID_SOCIAL_ENSURE_NUMBER  VARCHAR2(22),
  HOUSEHOLD_TYPE           VARCHAR2(3),
  HOUSEHOLD_STATE          VARCHAR2(20),
  HOUSEHOLD_ADDRESS        VARCHAR2(150),
  RESIDENT_ADDRESS_STATE   VARCHAR2(20),
  RESIDENT_ADDRESS         VARCHAR2(150),
  PERSONAL_STATUS          VARCHAR2(3),
  EDUCATION_LEVEL          VARCHAR2(3),
  ADMINISTRATIVE_POST      VARCHAR2(3),
  EMPLOYMENT_FORM          VARCHAR2(3),
  INSURANCE_RANGE          VARCHAR2(100),
  SALARY                   NUMBER(16,2),
  MOBILE                   VARCHAR2(20),
  TELEPHONE                VARCHAR2(20),
  POST_ADDRESS             VARCHAR2(100),
  ZIP_CODE                 VARCHAR2(6),
  JOIN_DATE                NUMBER(8),
  CHANGE_REASON            VARCHAR2(50),
  CHANGE_TYPE              VARCHAR2(3)
);
-- Add comments to the table 
comment on table APPLY_EMP_REGISTER
  is '个人增员申报信息表';
-- Add comments to the columns 
comment on column APPLY_EMP_REGISTER.ID
  is '申报事件ID';
comment on column APPLY_EMP_REGISTER.ID_TYPE
  is '证件类型';
comment on column APPLY_EMP_REGISTER.ID_NUMBER
  is '证件号码';
comment on column APPLY_EMP_REGISTER.ID_COUNTRY
  is '国家地区';
comment on column APPLY_EMP_REGISTER.NAME
  is '姓名';
comment on column APPLY_EMP_REGISTER.SEX
  is '性别';
comment on column APPLY_EMP_REGISTER.NATION
  is '民族';
comment on column APPLY_EMP_REGISTER.BIRTHDAY
  is '出生日期';
comment on column APPLY_EMP_REGISTER.WORK_DATE
  is '参加工作日期';
comment on column APPLY_EMP_REGISTER.ID_SOCIAL_ENSURE_NUMBER
  is '社会保障号码';
comment on column APPLY_EMP_REGISTER.HOUSEHOLD_TYPE
  is '户口性质';
comment on column APPLY_EMP_REGISTER.HOUSEHOLD_STATE
  is '户口所在区';
comment on column APPLY_EMP_REGISTER.HOUSEHOLD_ADDRESS
  is '户籍详细地址';
comment on column APPLY_EMP_REGISTER.RESIDENT_ADDRESS_STATE
  is '常住地所在区';
comment on column APPLY_EMP_REGISTER.RESIDENT_ADDRESS
  is '常住地详细地址';
comment on column APPLY_EMP_REGISTER.PERSONAL_STATUS
  is '个人身份';
comment on column APPLY_EMP_REGISTER.EDUCATION_LEVEL
  is '文化程度';
comment on column APPLY_EMP_REGISTER.ADMINISTRATIVE_POST
  is '行政职务';
comment on column APPLY_EMP_REGISTER.EMPLOYMENT_FORM
  is '用工形式';
comment on column APPLY_EMP_REGISTER.INSURANCE_RANGE
  is '参保险种范围';
comment on column APPLY_EMP_REGISTER.SALARY
  is '工资';
comment on column APPLY_EMP_REGISTER.MOBILE
  is '手机号码';
comment on column APPLY_EMP_REGISTER.TELEPHONE
  is '固定电话';
comment on column APPLY_EMP_REGISTER.POST_ADDRESS
  is '通讯地址';
comment on column APPLY_EMP_REGISTER.ZIP_CODE
  is '邮政编码';
comment on column APPLY_EMP_REGISTER.JOIN_DATE
  is '参保/续保日期';
comment on column APPLY_EMP_REGISTER.CHANGE_REASON
  is '变更原因';
comment on column APPLY_EMP_REGISTER.CHANGE_TYPE
  is '变更类型';
-- Create/Recreate primary, unique and foreign key constraints 
alter table APPLY_EMP_REGISTER
  add constraint PK_APPLY_EMP_REGISTER_ID primary key (ID)
  using index;
alter table APPLY_EMP_REGISTER
  add constraint FK_APPLY_EMP_REGISTER_ID foreign key (ID)
  references APPLY_EVENT (ID);

  
--减员申报表
  -- Create table
create table APPLY_EMP_DIMISSION
(
  ID              VARCHAR2(32) not null,
  INSURANCE_RANGE VARCHAR2(100),
  CHANGE_TYPE     VARCHAR2(100),
  CHANGE_REASON   VARCHAR2(200),
  DEATH_DATE      NUMBER(8)
);
-- Add comments to the table 
comment on table APPLY_EMP_DIMISSION
  is '减员申报表';
-- Add comments to the columns 
comment on column APPLY_EMP_DIMISSION.ID
  is 'ID';
comment on column APPLY_EMP_DIMISSION.INSURANCE_RANGE
  is '参保险种范围';
comment on column APPLY_EMP_DIMISSION.CHANGE_TYPE
  is '变更类型';
comment on column APPLY_EMP_DIMISSION.CHANGE_REASON
  is '变更原因';
comment on column APPLY_EMP_DIMISSION.DEATH_DATE
  is '死亡日期/变更日期';
-- Create/Recreate primary, unique and foreign key constraints 
alter table APPLY_EMP_DIMISSION
  add constraint PK_APPLY_PERSON_DIMISSION_ID primary key (ID)
  using index ;
alter table APPLY_EMP_DIMISSION
  add constraint FK_APPLY_PERSON_DIMISSION_ID foreign key (ID)
  references APPLY_EVENT (ID);
  
-- 职工年度工资申报
-- Create table
create table APPLY_EMP_SALARY
(
  PERSON_NUMBER VARCHAR2(22) not null,
  NAME          VARCHAR2(50),
  ID_NUMBER     VARCHAR2(22),
  YEAR          NUMBER(6),
  OLD_SALARY    NUMBER(16,2),
  NEW_SALARY    NUMBER(16,2),
  ORDER_INDEX	NUMBER(10),
  EVENT_ID      VARCHAR2(32) not null
);
-- Add comments to the table 
comment on table APPLY_EMP_SALARY
  is '职工年度工资申报表';
-- Add comments to the columns 
comment on column APPLY_EMP_SALARY.PERSON_NUMBER
  is '个人编号';
comment on column APPLY_EMP_SALARY.NAME
  is '姓名';
comment on column APPLY_EMP_SALARY.ID_NUMBER
  is '身份证号';
comment on column APPLY_EMP_SALARY.YEAR
  is '申报年度';
comment on column APPLY_EMP_SALARY.OLD_SALARY
  is '原工资';
comment on column APPLY_EMP_SALARY.NEW_SALARY
  is '新工资';
comment on column APPLY_EMP_SALARY.ORDER_INDEX
  is '序号';
comment on column APPLY_EMP_SALARY.EVENT_ID
  is '事件表ID';
-- Create/Recreate primary, unique and foreign key constraints 
alter table APPLY_EMP_SALARY
  add constraint PK_APPLY_EMP_SALARY_ID primary key (EVENT_ID, PERSON_NUMBER)
  using index;
alter table APPLY_EMP_SALARY
  add constraint FK_APPLY_EMP_SALARY_ID foreign key (EVENT_ID)
  references APPLY_EVENT (ID);
  

 -- 职工补缴申报表
-- Create table
create table APPLY_EMP_PAYOVERDUE
( ID              VARCHAR2(32) not null,
  BEGIN_ISSUE     NUMBER(6),
  END_ISSUE       NUMBER(6),
  INSURANCE_RANGE VARCHAR2(30),
  SALARY          NUMBER(16,2)
);
-- Add comments to the table 
comment on table APPLY_EMP_PAYOVERDUE
  is '职工补缴申报信息表';
-- Add comments to the columns 
comment on column APPLY_EMP_PAYOVERDUE.ID
  is '申报事件ID';
comment on column APPLY_EMP_PAYOVERDUE.BEGIN_ISSUE
  is '开始结算期';
comment on column APPLY_EMP_PAYOVERDUE.END_ISSUE
  is '终止结算期';
comment on column APPLY_EMP_PAYOVERDUE.INSURANCE_RANGE
  is '险种范围';
comment on column APPLY_EMP_PAYOVERDUE.SALARY
  is '工资';

-- Create/Recreate primary, unique and foreign key constraints 
alter table APPLY_EMP_PAYOVERDUE
  add constraint PK_APPLY_EMP_PAYOVERDUE_ID primary key (ID)
  using index;
alter table APPLY_EMP_PAYOVERDUE
  add constraint FK_APPLY_EMP_PAYOVERDUE_ID foreign key (ID)
  references APPLY_EVENT (ID);

--职工调整基数补差申报
-- Create table
create table APPLY_EMP_MAKEUPBALANCE
( 
  ID          VARCHAR2(32) not null,
  BEGIN_ISSUE NUMBER(6),
  END_ISSUE   NUMBER(6),
  SALARY      NUMBER(16,2)
);
-- Add comments to the table 
comment on table APPLY_EMP_MAKEUPBALANCE
  is '职工补缴申报信息表';
  
-- Add comments to the columns 
comment on column APPLY_EMP_MAKEUPBALANCE.ID
  is '申报事件ID';
comment on column APPLY_EMP_MAKEUPBALANCE.BEGIN_ISSUE
  is '开始结算期';
comment on column APPLY_EMP_MAKEUPBALANCE.END_ISSUE
  is '终止结算期';
comment on column APPLY_EMP_MAKEUPBALANCE.SALARY
  is '差额工资';

-- Create/Recreate primary, unique and foreign key constraints 
alter table APPLY_EMP_MAKEUPBALANCE
  add constraint PK_APPLY_EMP_MAKEUPBALANCE_ID primary key (ID)
  using index ;
alter table APPLY_EMP_MAKEUPBALANCE
  add constraint FK_APPLY_EMP_MAKEUPBALANCE_ID foreign key (ID)
  references APPLY_EVENT (ID);
 
  --养老待遇暂停申报表
  -- Create table
create table APPLY_EMP_RETIRE_PAUSE
(
  ID              VARCHAR2(32) not null,
  PAUSE_TYPE       VARCHAR2(3),
  PAUSE_REASON     VARCHAR2(200),
  PAUSE_DATE       NUMBER(8),
  REMARKS         VARCHAR2(200)
);
-- Add comments to the table 
comment on table APPLY_EMP_RETIRE_PAUSE
  is '养老待遇暂停申报表';
-- Add comments to the columns 
comment on column APPLY_EMP_RETIRE_PAUSE.ID
  is 'ID';
comment on column APPLY_EMP_RETIRE_PAUSE.PAUSE_TYPE
  is '停发类型';
comment on column APPLY_EMP_RETIRE_PAUSE.PAUSE_REASON
  is '停发原因';
comment on column APPLY_EMP_RETIRE_PAUSE.PAUSE_DATE
  is '停发开始时间';
comment on column APPLY_EMP_RETIRE_PAUSE.REMARKS
  is '备注';
-- Create/Recreate primary, unique and foreign key constraints 
alter table APPLY_EMP_RETIRE_PAUSE
  add constraint PK_APPLY_RETIRE_PAUSE_ID primary key (ID)
  using index;
alter table APPLY_EMP_RETIRE_PAUSE
  add constraint FK_APPLY_RETIRE_PAUSE_ID foreign key (ID)
  references APPLY_EVENT (ID);

  
  --业务预约配置信息表
  -- Create table
create table APPOINTMENT_CONFIG
(
  ID            VARCHAR2(32) not null,
  APPT_DATE     VARCHAR2(8),
  APPT_TIMESLOT VARCHAR2(3),
  BUZZ_TYPE     VARCHAR2(5),
  APPT_MAX      NUMBER(3),
  IS_OPEN       VARCHAR2(3),
  AGENCY_NUMBER VARCHAR2(16),
  AGENCY_NAME   VARCHAR2(200)
);
-- Add comments to the table 
comment on table APPOINTMENT_CONFIG
  is '网报预约配置表';
-- Add comments to the columns 
comment on column APPOINTMENT_CONFIG.ID
  is '预约id';
comment on column APPOINTMENT_CONFIG.APPT_DATE
  is '预约时间';
comment on column APPOINTMENT_CONFIG.APPT_TIMESLOT
  is '预约时段（ 0上午 1下午）';
comment on column APPOINTMENT_CONFIG.BUZZ_TYPE
  is '业务类型';
comment on column APPOINTMENT_CONFIG.APPT_MAX
  is '预约最大数量';
comment on column APPOINTMENT_CONFIG.IS_OPEN
  is '预约开放状态 （1可预约 2 禁止预约）';
comment on column APPOINTMENT_CONFIG.AGENCY_NUMBER
  is '经办机构编码';
comment on column APPOINTMENT_CONFIG.AGENCY_NAME
  is '经办机构名称';
-- Create/Recreate primary, unique and foreign key constraints 
alter table APPOINTMENT_CONFIG
  add constraint PK_APPT_CONFIG primary key (ID)
  using index;

create index IDEX_APPT_CONFIG_ID on APPOINTMENT_CONFIG (AGENCY_NUMBER, BUZZ_TYPE, APPT_DATE);
  
 --业务预约信息表
 -- Create table
create table APPOINTMENT_DETAIL
(
  ID                 VARCHAR2(32) not null,
  PARTY_ID           VARCHAR2(20),
  PARTY_NAME         VARCHAR2(200),
  PARTY_TYPE         VARCHAR2(3),
  IDNUMBER          VARCHAR2(22),
  MOBILE             VARCHAR2(20),
  BUZZ_TYPE          VARCHAR2(5),  
  APPT_DATE          NUMBER(8),
  APPT_TIMESLOT      VARCHAR2(3),
  APPT_NUMBER        NUMBER(3),
  APPT_STATE         VARCHAR2(3),
  CREATE_DATE        NUMBER(14),
  REVIEW_STATE       VARCHAR2(3),
  REVIEW_COMMENT     VARCHAR2(500),
  REVIEW_DATE        NUMBER(14),
  REVIEW_USER        VARCHAR2(50),
  AGENCY_NUMBER      VARCHAR2(16),
  AGENCY_NAME        VARCHAR2(200)
);
-- Add comments to the table  
comment on table APPOINTMENT_DETAIL
  is '预约信息表';
-- Add comments to the columns 
comment on column APPOINTMENT_DETAIL.ID
  is '预约ID';
comment on column APPOINTMENT_DETAIL.PARTY_ID
  is '主体id';
comment on column APPOINTMENT_DETAIL.PARTY_NAME
  is '主体名称';
comment on column APPOINTMENT_DETAIL.PARTY_TYPE
  is '主体类型';
comment on column APPOINTMENT_DETAIL.ID_NUMBER
  is '证件号码';
comment on column APPOINTMENT_DETAIL.MOBILE
  is '手机号码';
comment on column APPOINTMENT_DETAIL.BUZZ_TYPE
  is '业务类型';
comment on column APPOINTMENT_DETAIL.APPT_DATE
  is '预约日期';
comment on column APPOINTMENT_DETAIL.APPT_TIMESLOT
  is '预约时段';
comment on column APPOINTMENT_DETAIL.APPT_NUMBER
  is '预约号码';
comment on column APPOINTMENT_DETAIL.APPT_STATE
  is '预约状态(企业端) 1已预约 2预约取消';
comment on column APPOINTMENT_DETAIL.CREATE_DATE
  is '创建时间';
comment on column APPOINTMENT_DETAIL.REVIEW_STATE
  is '中心处理状态（1完成，2取消）';
comment on column APPOINTMENT_DETAIL.REVIEW_COMMENT
  is '中心处理意见';
comment on column APPOINTMENT_DETAIL.REVIEW_DATE
  is '中心处理时间';
comment on column APPOINTMENT_DETAIL.REVIEW_USER
  is '中心审核人姓名';
comment on column APPOINTMENT_DETAIL.AGENCY_NUMBER
  is '预约经办机构编号';
comment on column APPOINTMENT_DETAIL.AGENCY_NAME
  is '预约经办机构名称';
-- Create/Recreate primary, unique and foreign key constraints 
alter table APPOINTMENT_DETAIL
  add constraint PK_APPT_DETAIL primary key (ID)
  using index;
  
-- Create/Recreate indexes 
create index IDEX_APPT_DETAIL on APPOINTMENT_DETAIL (PARTY_ID, AGENCY_NUMBER, BUZZ_TYPE);
create index IDEX_APPT_DETAIL_DATE on APPOINTMENT_DETAIL (AGENCY_NUMBER, BUZZ_TYPE, APPT_DATE);
